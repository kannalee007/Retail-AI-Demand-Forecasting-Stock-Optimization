# 🚀 Retail AI Setup Guide

## Quick Start (5 Minutes)

### Prerequisites
- **Node.js 18+** (Download from https://nodejs.org/)
- **Yarn** package manager (Install: `npm install -g yarn`)

### Installation Steps

1. **Extract the ZIP file**
   ```bash
   unzip retail-ai-project.zip
   cd retail-ai-project
   ```

2. **Install dependencies**
   ```bash
   yarn install
   ```
   This will take 2-3 minutes.

3. **Start the development server**
   ```bash
   yarn dev
   ```

4. **Open your browser**
   - Navigate to: `http://localhost:3000`
   - You'll be redirected to the login page

5. **Login with demo credentials**
   - Email: `admin@retailai.com`
   - Password: `admin123`

## 🎉 That's it! You're ready to go!

---

## 📁 Project Structure

```
retail-ai-project/
├── app/                        # Next.js App Router
│   ├── api/                    # Backend API routes
│   │   ├── auth/              # Authentication
│   │   ├── products/          # Product management
│   │   ├── sales/             # Sales data
│   │   ├── forecast/          # Demand forecasting
│   │   ├── ai-insight/        # AI insights
│   │   └── chat/              # AI chat assistant
│   ├── login/                 # Login page
│   ├── dashboard/             # Main dashboard
│   ├── page.tsx               # Home page
│   ├── layout.tsx             # Root layout
│   └── globals.css            # Global styles
├── components/                 # React components
│   ├── DashboardCards.tsx
│   ├── ProductTable.tsx
│   ├── CSVUploader.tsx
│   ├── SalesChart.tsx
│   ├── AIChat.tsx
│   └── ui/                    # shadcn/ui components
├── src/
│   ├── ai/                    # AI service logic
│   │   ├── forecastService.ts
│   │   ├── insightService.ts
│   │   └── chatService.ts
│   └── types.ts               # TypeScript types
├── data/                      # JSON data storage
│   ├── products.json
│   └── sales_data.json
├── sample_sales_data.csv      # Sample CSV for testing
├── package.json
├── tsconfig.json
├── tailwind.config.js
└── README.md
```

---

## 🧪 Testing the Application

### 1. Login Flow
- Use credentials: `admin@retailai.com` / `admin123`

### 2. Dashboard Overview
- View metrics cards
- Check current inventory status

### 3. Upload CSV Data
- Go to "Upload Data" section
- Use the provided `sample_sales_data.csv` file
- Click "Choose CSV File" and select the sample file
- Wait for automatic forecast calculation

### 4. View Forecasts
- Navigate to "Demand Forecast"
- Check predicted demand for each product
- Review reorder recommendations

### 5. Manage Products
- Go to "Products" section
- Add a new product
- Edit existing products
- Delete test products

### 6. Ask AI Assistant
- Navigate to "AI Assistant"
- Try these questions:
  - "What products need restocking?"
  - "Tell me about Milk"
  - "Show me demand forecast"
  - "Which products have low stock?"

---

## 📊 CSV Upload Format

Your CSV file should have these columns:

```csv
date,product_id,units_sold
2024-06-01,P001,25
2024-06-01,P002,55
2024-06-02,P001,30
```

**Column Details:**
- `date` - Date in YYYY-MM-DD format
- `product_id` - Must match existing product IDs (P001, P002, etc.)
- `units_sold` - Number of units sold (integer)

---

## 🔧 Configuration

### Environment Variables (.env)
The project includes a `.env` file with default settings:
```
MONGO_URL=mongodb://localhost:27017
DB_NAME=your_database_name
NEXT_PUBLIC_BASE_URL=http://localhost:3000
CORS_ORIGINS=*
```

**Note:** MongoDB is NOT required for this application. We use local JSON files for storage.

---

## 🛠️ Available Scripts

```bash
# Start development server
yarn dev

# Build for production
yarn build

# Start production server
yarn start
```

---

## 📦 Key Dependencies

- **Next.js 14.2.3** - React framework
- **TypeScript 5.9.3** - Type safety
- **Tailwind CSS 3.4** - Styling
- **shadcn/ui** - UI components
- **Recharts 2.15** - Data visualization
- **PapaParse 5.4** - CSV parsing
- **Lucide React** - Icons

---

## 🎨 Customization

### Add More Products
Edit `/data/products.json`:
```json
{
  "product_id": "P006",
  "product_name": "Your Product",
  "category": "Category",
  "current_stock": 100,
  "predicted_demand": 0,
  "reorder_recommendation": 0
}
```

### Modify Forecast Algorithm
Edit `/src/ai/forecastService.ts`:
```typescript
// Change the growth factor from 1.15 to your desired value
const predicted_demand = Math.round(average * 1.15);
```

### Update Login Credentials
Edit `/app/api/auth/route.ts`:
```typescript
if (email === 'your@email.com' && password === 'yourpassword') {
  // Login logic
}
```

---

## 🐛 Troubleshooting

### Port 3000 already in use
```bash
# Find and kill the process using port 3000
lsof -ti:3000 | xargs kill -9

# Or use a different port
PORT=3001 yarn dev
```

### Module not found errors
```bash
# Clear cache and reinstall
rm -rf node_modules .next
yarn install
```

### TypeScript errors
```bash
# Rebuild TypeScript
yarn build
```

### CSV upload not working
- Check file format matches: `date,product_id,units_sold`
- Ensure product_id matches existing products
- Check browser console for errors

---

## 🚀 Deployment

### Vercel (Recommended)
1. Push code to GitHub
2. Import project in Vercel
3. Deploy (automatic)

### Other Platforms
- **Netlify**: Works with Next.js adapter
- **Railway**: One-click deploy
- **Docker**: Dockerfile included (if needed)

---

## 📝 Demo Credentials

**Always use these for testing:**
- Email: `admin@retailai.com`
- Password: `admin123`

---

## 🎯 Features Checklist

✅ Authentication system
✅ Product inventory management
✅ CSV sales data upload
✅ Demand forecasting algorithm
✅ AI-powered insights
✅ Chat assistant
✅ Interactive charts
✅ Responsive design
✅ TypeScript throughout
✅ Error handling
✅ Sample data included

---

## 📚 Learn More

- [Next.js Documentation](https://nextjs.org/docs)
- [TypeScript Handbook](https://www.typescriptlang.org/docs/)
- [Tailwind CSS](https://tailwindcss.com/docs)
- [shadcn/ui](https://ui.shadcn.com/)
- [Recharts](https://recharts.org/)

---

## 💡 Tips for Hackathon Demo

1. **Start with the overview** - Show dashboard metrics
2. **Upload CSV live** - Demonstrate real-time forecasting
3. **Highlight AI features** - Use chat assistant interactively
4. **Show CRUD operations** - Add/edit/delete a product
5. **Explain the algorithm** - Walk through forecast calculation
6. **Emphasize scalability** - Easy to add more AI features

---

## 🎉 You're All Set!

If you encounter any issues:
1. Check this guide first
2. Review the main README.md
3. Check browser console for errors
4. Ensure all dependencies are installed

**Happy Hacking! 🚀**
