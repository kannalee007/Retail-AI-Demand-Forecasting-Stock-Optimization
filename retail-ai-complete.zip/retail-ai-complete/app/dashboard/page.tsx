'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { 
  LayoutDashboard, 
  Package, 
  Upload, 
  BarChart3, 
  MessageSquare,
  LogOut,
  TrendingUp
} from 'lucide-react';
import DashboardCards from '@/components/DashboardCards';
import ProductTable from '@/components/ProductTable';
import CSVUploader from '@/components/CSVUploader';
import SalesChart from '@/components/SalesChart';
import AIChat from '@/components/AIChat';

export default function DashboardPage() {
  const router = useRouter();
  const [activeTab, setActiveTab] = useState('overview');
  const [products, setProducts] = useState([]);
  const [salesData, setSalesData] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check authentication
    const isLoggedIn = localStorage.getItem('isLoggedIn');
    if (isLoggedIn !== 'true') {
      router.push('/login');
      return;
    }

    fetchData();
  }, [router]);

  const fetchData = async () => {
    try {
      const [productsRes, salesRes] = await Promise.all([
        fetch('/api/products'),
        fetch('/api/sales')
      ]);

      const productsData = await productsRes.json();
      const salesDataResult = await salesRes.json();

      setProducts(productsData);
      setSalesData(salesDataResult);
      setLoading(false);
    } catch (error) {
      console.error('Failed to fetch data:', error);
      setLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('userEmail');
    router.push('/login');
  };

  const menuItems = [
    { id: 'overview', label: 'Overview', icon: LayoutDashboard },
    { id: 'products', label: 'Products', icon: Package },
    { id: 'upload', label: 'Upload Data', icon: Upload },
    { id: 'analytics', label: 'Analytics', icon: BarChart3 },
    { id: 'forecast', label: 'Demand Forecast', icon: TrendingUp },
    { id: 'ai-chat', label: 'AI Assistant', icon: MessageSquare },
  ];

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar */}
      <div className="w-64 border-r bg-card flex flex-col">
        <div className="p-6">
          <h1 className="text-xl font-bold">Retail AI</h1>
          <p className="text-xs text-muted-foreground mt-1">Demand Forecasting</p>
        </div>
        <Separator />
        <ScrollArea className="flex-1 px-3 py-4">
          <nav className="space-y-1">
            {menuItems.map((item) => {
              const Icon = item.icon;
              return (
                <Button
                  key={item.id}
                  variant={activeTab === item.id ? 'secondary' : 'ghost'}
                  className="w-full justify-start"
                  onClick={() => setActiveTab(item.id)}
                >
                  <Icon className="h-4 w-4 mr-3" />
                  {item.label}
                </Button>
              );
            })}
          </nav>
        </ScrollArea>
        <Separator />
        <div className="p-4">
          <Button variant="outline" className="w-full" onClick={handleLogout}>
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="border-b bg-card">
          <div className="px-6 py-4">
            <h2 className="text-2xl font-bold">
              {menuItems.find(item => item.id === activeTab)?.label}
            </h2>
          </div>
        </header>

        <main className="flex-1 overflow-auto p-6">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <DashboardCards products={products} />
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <SalesChart salesData={salesData} products={products} />
                <CSVUploader onUploadComplete={fetchData} />
              </div>
            </div>
          )}

          {activeTab === 'products' && (
            <ProductTable products={products} onProductUpdate={fetchData} />
          )}

          {activeTab === 'upload' && (
            <div className="max-w-2xl">
              <CSVUploader onUploadComplete={fetchData} />
              <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                <h3 className="font-semibold text-blue-900 mb-2">CSV Format Requirements</h3>
                <p className="text-sm text-blue-700 mb-2">Your CSV file should have the following columns:</p>
                <ul className="text-sm text-blue-700 list-disc list-inside space-y-1">
                  <li><strong>date:</strong> Date of sale (YYYY-MM-DD format)</li>
                  <li><strong>product_id:</strong> Product identifier (e.g., P001)</li>
                  <li><strong>units_sold:</strong> Number of units sold</li>
                </ul>
                <p className="text-xs text-blue-600 mt-3">
                  Example: 2024-01-01,P001,25
                </p>
              </div>
            </div>
          )}

          {activeTab === 'analytics' && (
            <div className="space-y-6">
              <SalesChart salesData={salesData} products={products} />
              <DashboardCards products={products} />
            </div>
          )}

          {activeTab === 'forecast' && (
            <div className="space-y-6">
              <DashboardCards products={products} />
              <ProductTable products={products} onProductUpdate={fetchData} />
            </div>
          )}

          {activeTab === 'ai-chat' && (
            <div className="max-w-4xl mx-auto">
              <AIChat />
            </div>
          )}
        </main>
      </div>
    </div>
  );
}