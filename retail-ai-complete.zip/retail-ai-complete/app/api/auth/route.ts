import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email, password } = body;
    
    // Simple authentication check
    if (email === 'admin@retailai.com' && password === 'admin123') {
      return NextResponse.json({ 
        success: true, 
        user: { email, name: 'Admin User' }
      });
    }
    
    return NextResponse.json({ 
      success: false, 
      error: 'Invalid credentials' 
    }, { status: 401 });
  } catch (error) {
    return NextResponse.json({ error: 'Authentication failed' }, { status: 500 });
  }
}