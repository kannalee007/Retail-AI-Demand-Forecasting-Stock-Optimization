import { NextRequest, NextResponse } from 'next/server';
import { generateInsight } from '@/src/ai/insightService';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { product_name, current_stock, predicted_demand } = body;
    
    if (!product_name || current_stock === undefined || predicted_demand === undefined) {
      return NextResponse.json({ 
        error: 'Missing required fields: product_name, current_stock, predicted_demand' 
      }, { status: 400 });
    }
    
    const insight = generateInsight({ product_name, current_stock, predicted_demand });
    return NextResponse.json({ insight });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to generate insight' }, { status: 500 });
  }
}