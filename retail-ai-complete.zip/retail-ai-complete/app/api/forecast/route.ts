import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import { calculateForecast, forecastAllProducts } from '@/src/ai/forecastService';

const productsPath = path.join(process.cwd(), 'data', 'products.json');
const salesPath = path.join(process.cwd(), 'data', 'sales_data.json');

function readProducts() {
  const data = fs.readFileSync(productsPath, 'utf-8');
  return JSON.parse(data);
}

function readSales() {
  const data = fs.readFileSync(salesPath, 'utf-8');
  return JSON.parse(data);
}

function writeProducts(products: any[]) {
  fs.writeFileSync(productsPath, JSON.stringify(products, null, 2));
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    // If product_id is provided, forecast single product
    if (body.product_id) {
      const { product_id, historical_sales } = body;
      const products = readProducts();
      const product = products.find((p: any) => p.product_id === product_id);
      
      if (!product) {
        return NextResponse.json({ error: 'Product not found' }, { status: 404 });
      }
      
      const forecast = calculateForecast(historical_sales, product.current_stock);
      return NextResponse.json(forecast);
    }
    
    // Otherwise, forecast all products
    const products = readProducts();
    const sales = readSales();
    const forecastedProducts = forecastAllProducts(sales, products);
    writeProducts(forecastedProducts);
    
    return NextResponse.json({ 
      message: 'Forecast updated for all products',
      products: forecastedProducts
    });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to calculate forecast' }, { status: 500 });
  }
}