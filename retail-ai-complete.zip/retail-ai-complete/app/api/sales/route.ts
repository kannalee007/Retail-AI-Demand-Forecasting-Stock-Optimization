import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

const salesPath = path.join(process.cwd(), 'data', 'sales_data.json');

function readSales() {
  const data = fs.readFileSync(salesPath, 'utf-8');
  return JSON.parse(data);
}

function writeSales(sales: any[]) {
  fs.writeFileSync(salesPath, JSON.stringify(sales, null, 2));
}

export async function GET() {
  try {
    const sales = readSales();
    return NextResponse.json(sales);
  } catch (error) {
    return NextResponse.json({ error: 'Failed to read sales data' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const newSales = await request.json();
    const existingSales = readSales();
    const updatedSales = [...existingSales, ...newSales];
    writeSales(updatedSales);
    return NextResponse.json({ 
      message: 'Sales data uploaded successfully', 
      count: newSales.length 
    }, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to upload sales data' }, { status: 500 });
  }
}