'use client';

import { useState, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Upload, FileText, CheckCircle2 } from 'lucide-react';
import Papa from 'papaparse';

interface CSVUploaderProps {
  onUploadComplete: () => void;
}

export default function CSVUploader({ onUploadComplete }: CSVUploaderProps) {
  const [uploading, setUploading] = useState(false);
  const [uploadStatus, setUploadStatus] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setUploading(true);
    setUploadStatus('Parsing CSV file...');

    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: async (results) => {
        try {
          setUploadStatus('Uploading sales data...');
          const response = await fetch('/api/sales', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(results.data)
          });

          if (response.ok) {
            const data = await response.json();
            setUploadStatus(`Successfully uploaded ${data.count} sales records!`);
            
            // Trigger forecast calculation
            await fetch('/api/forecast', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({})
            });
            
            setTimeout(() => {
              onUploadComplete();
              setUploadStatus('');
              setUploading(false);
            }, 2000);
          }
        } catch (error) {
          setUploadStatus('Failed to upload sales data');
          setUploading(false);
        }
      },
      error: (error) => {
        setUploadStatus('Failed to parse CSV file');
        setUploading(false);
      }
    });

    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileText className="h-5 w-5" />
          Upload Sales Data
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <p className="text-sm text-muted-foreground">
            Upload a CSV file with columns: date, product_id, units_sold
          </p>
          <div className="flex items-center gap-4">
            <input
              ref={fileInputRef}
              type="file"
              accept=".csv"
              onChange={handleFileUpload}
              className="hidden"
              id="csv-upload"
            />
            <Button
              onClick={() => fileInputRef.current?.click()}
              disabled={uploading}
              className="w-full"
            >
              <Upload className="h-4 w-4 mr-2" />
              {uploading ? 'Uploading...' : 'Choose CSV File'}
            </Button>
          </div>
          {uploadStatus && (
            <div className="flex items-center gap-2 p-3 bg-green-50 text-green-700 rounded-lg">
              <CheckCircle2 className="h-4 w-4" />
              <span className="text-sm">{uploadStatus}</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}