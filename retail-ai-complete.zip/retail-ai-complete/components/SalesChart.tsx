'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface SalesChartProps {
  salesData: any[];
  products: any[];
}

export default function SalesChart({ salesData, products }: SalesChartProps) {
  // Aggregate sales by date
  const salesByDate = salesData.reduce((acc: any, sale: any) => {
    const existing = acc.find((item: any) => item.date === sale.date);
    if (existing) {
      existing.units_sold += sale.units_sold;
    } else {
      acc.push({ date: sale.date, units_sold: sale.units_sold });
    }
    return acc;
  }, []);

  // Sort by date
  salesByDate.sort((a: any, b: any) => new Date(a.date).getTime() - new Date(b.date).getTime());

  // Aggregate sales by product
  const salesByProduct = products.map(product => {
    const productSales = salesData
      .filter(sale => sale.product_id === product.product_id)
      .reduce((sum, sale) => sum + sale.units_sold, 0);
    
    return {
      name: product.product_name,
      sales: productSales
    };
  }).sort((a, b) => b.sales - a.sales);

  return (
    <Card>
      <CardHeader>
        <CardTitle>Sales Analytics</CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="trend" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="trend">Sales Trend</TabsTrigger>
            <TabsTrigger value="products">Top Products</TabsTrigger>
          </TabsList>
          
          <TabsContent value="trend" className="pt-4">
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={salesByDate}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis 
                  dataKey="date" 
                  fontSize={12}
                  tickFormatter={(value) => new Date(value).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                />
                <YAxis fontSize={12} />
                <Tooltip />
                <Legend />
                <Line 
                  type="monotone" 
                  dataKey="units_sold" 
                  stroke="#8884d8" 
                  strokeWidth={2}
                  name="Units Sold"
                />
              </LineChart>
            </ResponsiveContainer>
          </TabsContent>
          
          <TabsContent value="products" className="pt-4">
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={salesByProduct}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" fontSize={12} />
                <YAxis fontSize={12} />
                <Tooltip />
                <Legend />
                <Bar dataKey="sales" fill="#82ca9d" name="Total Sales" />
              </BarChart>
            </ResponsiveContainer>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}