# Retail AI - Demand Forecasting & Stock Optimization System

A comprehensive web application for retail management featuring AI-based demand forecasting, stock optimization, and intelligent analytics.

## 🚀 Features

### 1. **Authentication**
- Simple email/password authentication
- Session management with localStorage
- Protected dashboard routes

**Demo Credentials:**
- Email: `admin@retailai.com`
- Password: `admin123`

### 2. **Inventory Dashboard**
- Real-time metrics display:
  - Total Products
  - Low Stock Items
  - Predicted Demand Summary
  - Stockout Risk Count
- Visual cards with icons and color coding

### 3. **Product Management**
- Full CRUD operations (Create, Read, Update, Delete)
- Dynamic product table with inline editing
- Columns: Product ID, Name, Category, Current Stock, Predicted Demand, Reorder Recommendation
- Status badges (Good/At Risk)

### 4. **CSV Upload & Sales Data**
- Upload historical sales data via CSV
- PapaParse library for CSV parsing
- Automatic forecast calculation after upload
- Expected CSV format: `date,product_id,units_sold`

### 5. **Sales Analytics**
- Interactive charts using Recharts:
  - Historical sales trend (Line Chart)
  - Top selling products (Bar Chart)
- Tab-based navigation
- Responsive design

### 6. **Demand Forecast**
- Automated forecasting algorithm: `predicted_demand = average(historical_sales) * 1.15`
- Reorder recommendations: `max(predicted_demand - current_stock, 0)`
- Batch forecast for all products
- Individual product forecast via API

### 7. **AI Insights**
- Context-aware product insights
- Stock shortage warnings
- Reorder timing recommendations
- Surplus stock notifications

### 8. **AI Chat Assistant**
- Interactive chat interface
- Natural language queries
- Product-specific information
- Stock level analysis
- Demand forecasting insights
- Reorder recommendations

## 🛠️ Tech Stack

### Frontend
- **Next.js 14+** with App Router
- **TypeScript** for type safety
- **Tailwind CSS** for styling
- **shadcn/ui** for UI components
- **Recharts** for data visualization
- **Lucide React** for icons

### Backend
- **Next.js API Routes** (serverless functions)
- **Node.js** filesystem for data persistence

### Storage
- **Local JSON files** in `/data` directory
  - `products.json` - Product inventory
  - `sales_data.json` - Historical sales records

### Libraries
- **PapaParse** - CSV parsing
- **date-fns** - Date formatting

## 📁 Project Structure

```
/app
├── app/
│   ├── api/
│   │   ├── auth/route.ts          # Authentication endpoint
│   │   ├── products/route.ts      # Product CRUD operations
│   │   ├── sales/route.ts         # Sales data management
│   │   ├── forecast/route.ts      # Demand forecasting
│   │   ├── ai-insight/route.ts    # AI insights generation
│   │   └── chat/route.ts          # AI chat assistant
│   ├── login/page.tsx             # Login page
│   ├── dashboard/page.tsx         # Main dashboard
│   ├── page.tsx                   # Home/redirect page
│   ├── layout.tsx                 # Root layout
│   └── globals.css                # Global styles
├── components/
│   ├── DashboardCards.tsx         # Metrics cards
│   ├── ProductTable.tsx           # Product management table
│   ├── CSVUploader.tsx            # CSV upload component
│   ├── SalesChart.tsx             # Analytics charts
│   ├── AIChat.tsx                 # Chat interface
│   └── ui/                        # shadcn/ui components
├── src/
│   ├── ai/
│   │   ├── forecastService.ts     # Forecasting logic
│   │   ├── insightService.ts      # Insights generation
│   │   └── chatService.ts         # Chat response logic
│   └── types.ts                   # TypeScript interfaces
├── data/
│   ├── products.json              # Product data
│   └── sales_data.json            # Sales records
└── package.json
```

## 🚦 Getting Started

### Prerequisites
- Node.js 18+ and Yarn

### Installation

1. **Install dependencies:**
   ```bash
   yarn install
   ```

2. **Run development server:**
   ```bash
   yarn dev
   ```

3. **Access the application:**
   - Open browser: `http://localhost:3000`
   - Login with demo credentials
   - Start exploring!

## 📊 Usage Guide

### Demo Flow

1. **Login**
   - Navigate to the login page
   - Use demo credentials: `admin@retailai.com` / `admin123`
   - Click "Sign In"

2. **View Dashboard**
   - See overview metrics and charts
   - Check current inventory status
   - Review stockout risks

3. **Upload Sales Data**
   - Go to "Upload Data" section
   - Click "Choose CSV File"
   - Select a CSV file with format: `date,product_id,units_sold`
   - Wait for upload and automatic forecast calculation

4. **View Forecast**
   - Navigate to "Demand Forecast"
   - Check predicted demand for each product
   - Review reorder recommendations
   - Identify products at risk

5. **Manage Products**
   - Go to "Products" section
   - Add new products with "Add Product" button
   - Edit existing products (pencil icon)
   - Delete products (trash icon)

6. **Analyze Sales**
   - Open "Analytics" section
   - Switch between Sales Trend and Top Products charts
   - Identify best-selling items

7. **Ask AI Assistant**
   - Navigate to "AI Assistant"
   - Type questions like:
     - "What products need restocking?"
     - "Show me stock levels"
     - "Tell me about Milk"
     - "What's the demand forecast?"

## 🔧 API Endpoints

### Authentication
- `POST /api/auth` - Login with credentials

### Products
- `GET /api/products` - Get all products
- `POST /api/products` - Add new product
- `PUT /api/products` - Update existing product
- `DELETE /api/products?product_id=P001` - Delete product

### Sales
- `GET /api/sales` - Get all sales records
- `POST /api/sales` - Upload new sales data (array)

### Forecasting
- `POST /api/forecast` - Calculate forecast for all products
- `POST /api/forecast` with `{product_id, historical_sales}` - Forecast single product

### AI Services
- `POST /api/ai-insight` - Generate insight for product
- `POST /api/chat` - Send message to AI assistant

## 🎨 Design Features

- **Modern UI** with shadcn/ui components
- **Responsive layout** for all screen sizes
- **Dark mode support** (via theme provider)
- **Sidebar navigation** with active states
- **Card-based dashboard** sections
- **Color-coded status** indicators
- **Smooth animations** and transitions
- **Professional typography** using Inter font

## 📈 Forecasting Algorithm

The system uses a simple yet effective forecasting algorithm:

```typescript
predicted_demand = average(historical_sales) * 1.15

reorder_recommendation = max(predicted_demand - current_stock, 0)

stockout_risk = predicted_demand > current_stock
```

This 15% growth factor accounts for typical seasonal trends and business growth.

## 🤖 AI Capabilities

### Insight Generation
- Analyzes stock vs. demand
- Provides contextual recommendations
- Identifies potential shortages
- Suggests reorder timing

### Chat Assistant
- Natural language understanding
- Product-specific queries
- Stock level analysis
- Demand trends explanation
- Reorder recommendations

## 🔐 Security Notes

This is a **demo application** with simplified authentication:
- Uses localStorage for session management
- No password hashing
- No JWT tokens
- Suitable for hackathon/demo purposes only

For production use, implement:
- Proper authentication (JWT, OAuth)
- Password hashing (bcrypt)
- Session management (Redis)
- HTTPS enforcement
- CSRF protection
- Rate limiting

## 🎯 Future Enhancements

- Real database integration (PostgreSQL, MongoDB)
- Advanced ML models for forecasting
- Multi-user support with roles
- Email notifications for low stock
- Automated reorder system
- Supplier management
- Price optimization
- Seasonal trend analysis
- Export reports to PDF
- Real-time inventory updates
- Mobile app version

## 📝 Sample Data

The application comes with pre-loaded sample data:

### Products
- Milk (Dairy)
- Bread (Bakery)
- Eggs (Dairy)
- Soft Drinks (Beverages)
- Rice (Grains)

### Sales Records
- Historical data for all products
- Date range: January 2024
- Multiple entries per product

## 🐛 Troubleshooting

**Issue: Application won't start**
- Check Node.js version (18+)
- Run `yarn install`
- Delete `.next` folder and restart

**Issue: Forecast not updating**
- Ensure sales data is uploaded
- Check data format matches: `date,product_id,units_sold`
- Verify product_id exists in products.json

**Issue: Authentication fails**
- Use exact credentials: `admin@retailai.com` / `admin123`
- Clear localStorage and try again

**Issue: Charts not displaying**
- Check browser console for errors
- Ensure sales data exists
- Verify Recharts is installed

## 📄 License

MIT License - Feel free to use for hackathons, demos, and learning purposes.

## 👥 Contributing

This is a hackathon demo project. Feel free to fork and enhance!

## 🏆 Hackathon Ready

This application is fully functional and ready for demonstration:
- ✅ Compiles without errors
- ✅ All features working
- ✅ Professional UI/UX
- ✅ Sample data included
- ✅ Easy to extend
- ✅ Well-documented
- ✅ Modern tech stack

## 📞 Support

For issues or questions, check:
1. This README
2. Code comments
3. TypeScript types
4. API response messages

---

**Built with ❤️ for Retail Innovation Hackathon**
