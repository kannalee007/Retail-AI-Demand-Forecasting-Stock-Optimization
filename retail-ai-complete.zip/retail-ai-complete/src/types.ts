export interface Product {
  product_id: string;
  product_name: string;
  category: string;
  current_stock: number;
  predicted_demand: number;
  reorder_recommendation: number;
}

export interface SalesRecord {
  date: string;
  product_id: string;
  units_sold: number;
}

export interface ForecastRequest {
  product_id: string;
  historical_sales: number[];
}

export interface ForecastResponse {
  predicted_demand: number;
  recommended_reorder: number;
}

export interface InsightRequest {
  product_name: string;
  current_stock: number;
  predicted_demand: number;
}

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}