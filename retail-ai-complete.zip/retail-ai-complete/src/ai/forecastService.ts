import { ForecastRequest, ForecastResponse } from '../types';

export function calculateForecast(
  historical_sales: number[],
  current_stock: number
): ForecastResponse {
  if (historical_sales.length === 0) {
    return {
      predicted_demand: 0,
      recommended_reorder: 0
    };
  }

  const average = historical_sales.reduce((sum, val) => sum + val, 0) / historical_sales.length;
  const predicted_demand = Math.round(average * 1.15);
  const recommended_reorder = Math.max(predicted_demand - current_stock, 0);

  return {
    predicted_demand,
    recommended_reorder
  };
}

export function forecastAllProducts(salesData: any[], products: any[]): any[] {
  return products.map(product => {
    const productSales = salesData
      .filter(sale => sale.product_id === product.product_id)
      .map(sale => sale.units_sold);

    const forecast = calculateForecast(productSales, product.current_stock);

    return {
      ...product,
      predicted_demand: forecast.predicted_demand,
      reorder_recommendation: forecast.recommended_reorder
    };
  });
}