import { ChatMessage } from '../types';

export function generateChatResponse(message: string, products: any[]): string {
  const lowercaseMessage = message.toLowerCase();

  // Check for stock-related queries
  if (lowercaseMessage.includes('stock') || lowercaseMessage.includes('inventory')) {
    const lowStockProducts = products.filter(p => p.predicted_demand > p.current_stock);
    if (lowStockProducts.length > 0) {
      const productNames = lowStockProducts.map(p => p.product_name).join(', ');
      return `Based on current data, you should monitor the following products where predicted demand exceeds current stock: ${productNames}. Consider restocking these items soon.`;
    }
    return 'All products currently have adequate stock levels based on predicted demand.';
  }

  // Check for demand-related queries
  if (lowercaseMessage.includes('demand') || lowercaseMessage.includes('forecast')) {
    const totalDemand = products.reduce((sum, p) => sum + p.predicted_demand, 0);
    const avgDemand = Math.round(totalDemand / products.length);
    return `Total predicted demand across all products is ${totalDemand} units. Average predicted demand per product is ${avgDemand} units. Products are forecasted based on historical sales trends with a 15% growth factor.`;
  }

  // Check for specific product queries
  const productMentioned = products.find(p => 
    lowercaseMessage.includes(p.product_name.toLowerCase())
  );
  
  if (productMentioned) {
    const status = productMentioned.predicted_demand > productMentioned.current_stock 
      ? 'needs restocking' 
      : 'has adequate stock';
    return `${productMentioned.product_name} ${status}. Current stock: ${productMentioned.current_stock} units. Predicted demand: ${productMentioned.predicted_demand} units. Reorder recommendation: ${productMentioned.reorder_recommendation} units.`;
  }

  // Check for reorder queries
  if (lowercaseMessage.includes('reorder') || lowercaseMessage.includes('order')) {
    const needsReorder = products.filter(p => p.reorder_recommendation > 0);
    if (needsReorder.length > 0) {
      const recommendations = needsReorder
        .map(p => `${p.product_name}: ${p.reorder_recommendation} units`)
        .join(', ');
      return `Reorder recommendations: ${recommendations}`;
    }
    return 'No products currently need reordering based on predicted demand.';
  }

  // Default response
  return `I'm your AI retail assistant. I can help you with:
- Stock level analysis
- Demand forecasting insights
- Reorder recommendations
- Product-specific information

Try asking about stock levels, demand forecasts, or specific products!`;
}