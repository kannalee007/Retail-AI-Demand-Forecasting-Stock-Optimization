import { InsightRequest } from '../types';

export function generateInsight(request: InsightRequest): string {
  const { product_name, current_stock, predicted_demand } = request;

  if (predicted_demand > current_stock) {
    const shortage = predicted_demand - current_stock;
    return `Demand for ${product_name} is expected to increase based on recent sales trends. Current stock (${current_stock} units) may not be sufficient to meet predicted demand (${predicted_demand} units). You have a potential shortage of ${shortage} units. Consider restocking soon to avoid stockouts.`;
  } else if (predicted_demand === 0) {
    return `No sales data available for ${product_name}. Consider uploading historical sales data to get accurate demand predictions.`;
  } else {
    const surplus = current_stock - predicted_demand;
    return `${product_name} stock levels are adequate. Current stock (${current_stock} units) exceeds predicted demand (${predicted_demand} units) by ${surplus} units. No immediate restocking needed.`;
  }
}