#!/bin/bash

echo "🚀 Retail AI - Installation Verification Script"
echo "================================================"
echo ""

# Check Node.js
echo "✓ Checking Node.js..."
if command -v node &> /dev/null; then
    NODE_VERSION=$(node -v)
    echo "  ✅ Node.js installed: $NODE_VERSION"
    
    # Check if version is 18+
    MAJOR_VERSION=$(echo $NODE_VERSION | cut -d'.' -f1 | sed 's/v//')
    if [ "$MAJOR_VERSION" -ge 18 ]; then
        echo "  ✅ Version is 18 or higher - Good!"
    else
        echo "  ⚠️  Warning: Node.js 18+ recommended (you have v$MAJOR_VERSION)"
    fi
else
    echo "  ❌ Node.js not found. Please install from https://nodejs.org/"
    exit 1
fi

echo ""

# Check Yarn
echo "✓ Checking Yarn..."
if command -v yarn &> /dev/null; then
    YARN_VERSION=$(yarn -v)
    echo "  ✅ Yarn installed: v$YARN_VERSION"
else
    echo "  ⚠️  Yarn not found. Installing..."
    npm install -g yarn
    if [ $? -eq 0 ]; then
        echo "  ✅ Yarn installed successfully"
    else
        echo "  ❌ Failed to install Yarn"
        exit 1
    fi
fi

echo ""

# Check project files
echo "✓ Checking project files..."
REQUIRED_FILES=(
    "package.json"
    "tsconfig.json"
    "app/page.tsx"
    "app/layout.tsx"
    "data/products.json"
    "data/sales_data.json"
)

for file in "${REQUIRED_FILES[@]}"; do
    if [ -f "$file" ]; then
        echo "  ✅ Found: $file"
    else
        echo "  ❌ Missing: $file"
        exit 1
    fi
done

echo ""

# Install dependencies
echo "✓ Installing dependencies..."
echo "  This may take 2-3 minutes..."
yarn install --silent

if [ $? -eq 0 ]; then
    echo "  ✅ Dependencies installed successfully"
else
    echo "  ❌ Failed to install dependencies"
    exit 1
fi

echo ""
echo "================================================"
echo "✅ Installation Complete!"
echo ""
echo "📝 Quick Start:"
echo "   1. Run: yarn dev"
echo "   2. Open: http://localhost:3000"
echo "   3. Login: admin@retailai.com / admin123"
echo ""
echo "📖 For more details, see SETUP_GUIDE.md"
echo "================================================"
